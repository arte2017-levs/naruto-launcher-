/* Se ejecuta al inicio de CADA página/iframe, antes que los scripts del juego.
   1) Configura Ruffle (se añade después, en el mismo bloque).
   2) Ajusta la calidad (devicePixelRatio).
   3) Expone window.__ld para enviar teclas/texto desde los controles nativos. */
(function () {
  if (window.__ld) return;
  var C = window.__LD_CONFIG || {};

  // ---- Calidad: bajar el DPR reduce mucho el tamaño del canvas (RAM/CPU/GPU)
  try {
    var real = window.devicePixelRatio || 1;
    var dpr = C.dpr > 0 ? C.dpr : real;
    Object.defineProperty(window, 'devicePixelRatio', { get: function () { return dpr; }, configurable: true });
  } catch (e) {}

  // ---- Config de Ruffle (debe existir antes de ruffle.js)
  var prev = (window.RufflePlayer && window.RufflePlayer.config) || {};
  window.RufflePlayer = window.RufflePlayer || {};
  window.RufflePlayer.config = Object.assign({
    publicPath: C.publicPath,
    autoplay: 'on',
    unmuteOverlay: 'hidden',
    splashScreen: false,
    letterbox: 'on',
    quality: C.quality || 'medium',
    warnOnUnsupportedContent: false,
    contextMenu: 'off',
    showSwfDownload: false,
    polyfills: true,
    logLevel: 'info'
  }, prev);

  if (C.renderer) window.RufflePlayer.config.preferredRenderer = C.renderer;

  // ---- Permitir pellizcar para hacer zoom
  document.addEventListener('DOMContentLoaded', function () {
    var m = document.querySelector('meta[name=viewport]');
    if (m) m.setAttribute('content', 'width=device-width, initial-scale=1, maximum-scale=10, user-scalable=yes');
  });

  // ---- Envío de teclas / texto
  function hasPlayer() {
    if (document.querySelector('ruffle-player,ruffle-object,ruffle-embed')) return true;
    var cs = document.getElementsByTagName('canvas');
    for (var i = 0; i < cs.length; i++) if (cs[i].width > 200 && cs[i].height > 150) return true;
    return false;
  }
  function target() {
    var a = document.activeElement;
    if (a && a !== document.body && a !== document.documentElement && a.tagName !== 'IFRAME') return a;
    return document.querySelector('ruffle-player,ruffle-object,ruffle-embed') ||
           document.querySelector('canvas') || document.body || document.documentElement;
  }
  function mk(type, o) {
    var ev = new KeyboardEvent(type, { key: o.key, code: o.code, keyCode: o.kc, which: o.kc,
      bubbles: true, cancelable: true, composed: true });
    if (ev.keyCode !== o.kc) {
      try {
        Object.defineProperty(ev, 'keyCode', { get: function () { return o.kc; } });
        Object.defineProperty(ev, 'which', { get: function () { return o.kc; } });
      } catch (e) {}
    }
    return ev;
  }
  function sendKey(type, o) {
    var t = target();
    try { if (type === 'down' && t.focus) t.focus(); } catch (e) {}
    t.dispatchEvent(mk(type === 'down' ? 'keydown' : 'keyup', o));
  }
  var ENTER = { key: 'Enter', code: 'Enter', kc: 13 };
  function charDef(ch) {
    var up = ch.toUpperCase(), kc = up.length === 1 ? up.charCodeAt(0) : 0;
    var code = /[a-z]/i.test(ch) ? 'Key' + up : /[0-9]/.test(ch) ? 'Digit' + ch : ch === ' ' ? 'Space' : '';
    if (kc > 127) kc = 0;
    return { key: ch, code: code, kc: kc };
  }
  function typeText(text, enter) {
    var chars = Array.from(text), i = 0;
    (function step() {
      if (i < chars.length) {
        var o = charDef(chars[i++]), t = target();
        t.dispatchEvent(mk('keydown', o));
        t.dispatchEvent(mk('keypress', o));
        t.dispatchEvent(mk('keyup', o));
        setTimeout(step, 6);
      } else if (enter) {
        sendKey('down', ENTER); sendKey('up', ENTER);
      }
    })();
  }
  function forward(msg) {
    var f = document.getElementsByTagName('iframe');
    for (var i = 0; i < f.length; i++) { try { f[i].contentWindow.postMessage(msg, '*'); } catch (e) {} }
  }
  function handle(m) {
    if (!m || m.__ld !== 1) return;
    if (hasPlayer()) {
      if (m.cmd === 'key') sendKey(m.type, m.o);
      else if (m.cmd === 'type') typeText(m.text, m.enter);
    }
    forward(m);
  }
  window.addEventListener('message', function (e) { if (e.data && e.data.__ld === 1) handle(e.data); });
  window.__ld = {
    key: function (type, o) { handle({ __ld: 1, cmd: 'key', type: type, o: o }); },
    type: function (text, enter) { handle({ __ld: 1, cmd: 'type', text: text, enter: !!enter }); }
  };
})();
