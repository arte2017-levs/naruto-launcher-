/* Se ejecuta al inicio de CADA página/iframe, antes que los scripts del juego.
   1) Configura Ruffle (se añade después, en el mismo bloque).
   2) Ajusta la calidad (devicePixelRatio).
   3) Expone window.__ld para enviar teclas/texto desde los controles nativos. */
(function () {
  if (window.__ld) return;
  var C = window.__LD_CONFIG || {};

  // ---- Calidad: bajar el DPR reduce mucho el tamaño del canvas (RAM/CPU/GPU)
  try {
    var real = window.devicePixelRatio || 1;
    var dpr = C.dpr > 0 ? C.dpr : real;
    Object.defineProperty(window, 'devicePixelRatio', { get: function () { return dpr; }, configurable: true });
  } catch (e) {}

  // ---- Config de Ruffle (debe existir antes de ruffle.js)
  var prev = (window.RufflePlayer && window.RufflePlayer.config) || {};
  window.RufflePlayer = window.RufflePlayer || {};
  window.RufflePlayer.config = Object.assign({
    publicPath: C.publicPath,
    autoplay: 'on',
    unmuteOverlay: 'hidden',
    splashScreen: false,
    letterbox: 'on',
    quality: C.quality || 'medium',
    warnOnUnsupportedContent: false,
    contextMenu: 'off',
    showSwfDownload: false,
    polyfills: true,
    logLevel: 'info'
  }, prev);

  if (C.renderer) window.RufflePlayer.config.preferredRenderer = C.renderer;

  // ---- Permitir pellizcar para hacer zoom
  document.addEventListener('DOMContentLoaded', function () {
    var m = document.querySelector('meta[name=viewport]');
    if (m) m.setAttribute('content', 'width=device-width, initial-scale=1, maximum-scale=10, user-scalable=yes');
  });

  // ---- Envío de teclas / texto
  function hasPlayer() {
    if (document.querySelector('ruffle-player,ruffle-object,ruffle-embed')) return true;
    var cs = document.getElementsByTagName('canvas');
    for (var i = 0; i < cs.length; i++) if (cs[i].width > 200 && cs[i].height > 150) return true;
    return false;
  }
  function target() {
    var a = document.activeElement;
    if (a && a !== document.body && a !== document.documentElement && a.tagName !== 'IFRAME') return a;
    return document.querySelector('ruffle-player,ruffle-object,ruffle-embed') ||
           document.querySelector('canvas') || document.body || document.documentElement;
  }
  function mk(type, o) {
    var ev = new KeyboardEvent(type, { key: o.key, code: o.code, keyCode: o.kc, which: o.kc,
      bubbles: true, cancelable: true, composed: true });
    if (ev.keyCode !== o.kc) {
      try {
        Object.defineProperty(ev, 'keyCode', { get: function () { return o.kc; } });
        Object.defineProperty(ev, 'which', { get: function () { return o.kc; } });
      } catch (e) {}
    }
    return ev;
  }
  function sendKey(type, o) {
    var t = target();
    try { if (type === 'down' && t.focus) t.focus(); } catch (e) {}
    t.dispatchEvent(mk(type === 'down' ? 'keydown' : 'keyup', o));
  }
  var ENTER = { key: 'Enter', code: 'Enter', kc: 13 };
  function charDef(ch) {
    var up = ch.toUpperCase(), kc = up.length === 1 ? up.charCodeAt(0) : 0;
    var code = /[a-z]/i.test(ch) ? 'Key' + up : /[0-9]/.test(ch) ? 'Digit' + ch : ch === ' ' ? 'Space' : '';
    if (kc > 127) kc = 0;
    return { key: ch, code: code, kc: kc };
  }
  function typeText(text, enter) {
    var chars = Array.from(text), i = 0;
    (function step() {
      if (i < chars.length) {
        var o = charDef(chars[i++]), t = target();
        t.dispatchEvent(mk('keydown', o));
        t.dispatchEvent(mk('keypress', o));
        t.dispatchEvent(mk('keyup', o));
        setTimeout(step, 6);
      } else if (enter) {
        sendKey('down', ENTER); sendKey('up', ENTER);
      }
    })();
  }
  function forward(msg) {
    var f = document.getElementsByTagName('iframe');
    for (var i = 0; i < f.length; i++) { try { f[i].contentWindow.postMessage(msg, '*'); } catch (e) {} }
  }
  // ---- Detección y "modo Flash"
  function abs(u) { try { return new URL(u, document.baseURI).href; } catch (e) { return u; } }
  function param(el, name) {
    var ps = el.querySelectorAll('param');
    for (var i = 0; i < ps.length; i++) if ((ps[i].getAttribute('name') || '').toLowerCase() === name) return ps[i].getAttribute('value') || '';
    return '';
  }
  function plainFlash() {
    var out = [], els = document.querySelectorAll('embed,object');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.tagName === 'EMBED' && el.parentNode && el.parentNode.tagName === 'OBJECT') continue;
      var u, fv, base, type = (el.getAttribute('type') || '').toLowerCase();
      if (el.tagName === 'EMBED') { u = el.getAttribute('src'); fv = el.getAttribute('flashvars'); base = el.getAttribute('base'); }
      else {
        u = el.getAttribute('data') || param(el, 'movie') || param(el, 'src');
        fv = param(el, 'flashvars'); base = param(el, 'base');
        var emb = el.querySelector('embed');
        if (!u && emb) { u = emb.getAttribute('src'); fv = fv || emb.getAttribute('flashvars'); }
      }
      var isSwf = /shockwave|flash/.test(type) || /\.swf(\?|#|$)/i.test(u || '') || /d27cdb6e/i.test(el.getAttribute('classid') || '');
      out.push({ el: el, url: (u && isSwf) ? abs(u) : '', fv: fv || '', base: base ? abs(base) : '' });
    }
    return out;
  }
  function scan() {
    var items = [], pf = plainFlash();
    pf.forEach(function (f) { if (f.url) items.push({ url: f.url, fv: f.fv, base: f.base }); });
    return { frame: location.href, items: items, plain: pf.length,
             ruffle: document.querySelectorAll('ruffle-player,ruffle-object,ruffle-embed').length };
  }
  function report() {
    var r = scan();
    if ((r.items.length || r.plain) && window.LDNative) { try { window.LDNative.postMessage(JSON.stringify(r)); } catch (e) {} }
  }
  function px(v) { return /^\d+$/.test(v || '') ? v + 'px' : (v || '100%'); }
  function forceFlash() {
    var R = window.RufflePlayer && window.RufflePlayer.newest && window.RufflePlayer.newest();
    if (!R) return;
    plainFlash().forEach(function (f) {
      if (!f.url) return;
      try {
        var el = f.el, r = el.getBoundingClientRect(), p = R.createPlayer();
        p.style.width = r.width > 0 ? r.width + 'px' : px(el.getAttribute('width'));
        p.style.height = r.height > 0 ? r.height + 'px' : px(el.getAttribute('height'));
        if (el.parentNode) el.parentNode.replaceChild(p, el);
        var cfg = { url: f.url, allowScriptAccess: true };
        if (f.fv) cfg.parameters = f.fv;
        if (f.base) cfg.base = f.base;
        p.load(cfg);
      } catch (e) { console.warn('LD flash mode: ' + e); }
    });
    setTimeout(report, 500);
  }
  [0, 2000, 6000, 12000].forEach(function (t) { setTimeout(report, t); });
  document.addEventListener('DOMContentLoaded', report);
  window.addEventListener('load', report);

  function handle(m) {
    if (!m || m.__ld !== 1) return;
    if (m.cmd === 'flash') forceFlash();
    else if (hasPlayer()) {
      if (m.cmd === 'key') sendKey(m.type, m.o);
      else if (m.cmd === 'type') typeText(m.text, m.enter);
    }
    forward(m);
  }
  window.addEventListener('message', function (e) { if (e.data && e.data.__ld === 1) handle(e.data); });
  window.__ld = {
    key: function (type, o) { handle({ __ld: 1, cmd: 'key', type: type, o: o }); },
    type: function (text, enter) { handle({ __ld: 1, cmd: 'type', text: text, enter: !!enter }); },
    flashMode: function () { handle({ __ld: 1, cmd: 'flash' }); }
  };
})();
