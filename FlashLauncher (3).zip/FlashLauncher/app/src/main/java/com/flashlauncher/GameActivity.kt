package com.flashlauncher

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class GameActivity : AppCompatActivity(), ControlsOverlay.Host, VirtualMouseView.Host {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_NAME = "name"
        const val EXTRA_SWF = "swf"
        private const val HOST = "ruffle.local"
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }

    private lateinit var s: Settings
    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var controls: ControlsOverlay
    private lateinit var mouse: VirtualMouseView
    private lateinit var menuBar: HorizontalScrollView
    private lateinit var chatBar: LinearLayout
    private lateinit var chatInput: EditText
    private lateinit var fsContainer: FrameLayout
    private lateinit var flashBtn: TextView
    private val detected = LinkedHashMap<String, SwfInfo>()
    private var playerReferer: String? = null
    private var currentUa = DESKTOP_UA

    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var scriptHandler: ScriptHandler? = null
    private var profile = "default"
    private var swfUri: Uri? = null
    private var ruffleJs: String? = null
    private var pageScale = 1f
    private var baseScale = 0f
    private var downTime = 0L
    private val logs = ArrayDeque<String>()

    private fun addLog(m: String) = synchronized(logs) { if (logs.size > 120) logs.removeFirst(); logs.addLast(m) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ================================================================ ciclo de vida
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Settings(this)
        swfUri = intent.getStringExtra(EXTRA_SWF)?.let { Uri.parse(it) }
        val url = if (swfUri != null) "https://$HOST/player.html" else intent.getStringExtra(EXTRA_URL) ?: "about:blank"
        profile = (intent.getStringExtra(EXTRA_NAME) ?: url).hashCode().toString()

        ruffleJs = try { assets.open("ruffle/ruffle.js").bufferedReader().use { it.readText() } } catch (e: Exception) { null }
        if (ruffleJs == null) Toast.makeText(this, "Falta Ruffle: ejecuta scripts/fetch_ruffle.sh", Toast.LENGTH_LONG).show()

        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()
        setupWebView()
        applyWindowMode()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    fsContainer.visibility == View.VISIBLE -> hideCustomView()
                    controls.editMode -> controls.editMode = false
                    web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })
        web.loadUrl(url)
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) applyWindowMode() }
    override fun onTrimMemory(level: Int) { super.onTrimMemory(level); if (s.lowRam) web.clearCache(false) }
    override fun onDestroy() {
        if (s.lowRam) web.clearCache(true)
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    // ================================================================ UI
    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        web = WebView(this)
        root.addView(web, match())

        fsContainer = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); visibility = View.GONE }
        root.addView(fsContainer, match())

        mouse = VirtualMouseView(this).apply { host = this@GameActivity; speed = s.mouseSpeed; visibility = View.GONE }
        root.addView(mouse, match())

        controls = ControlsOverlay(this).apply {
            host = this@GameActivity
            controlAlpha = s.controlsAlpha
            setItems(ControlLayout.fromJson(s.layoutJson(profile)))
            visibility = if (s.controlsVisible) View.VISIBLE else View.GONE
        }
        root.addView(controls, match())

        // --- barra de chat (escribe texto dentro del juego)
        chatInput = EditText(this).apply {
            hint = "Escribe un mensaje…"; setHintTextColor(0xFF9AA4B2.toInt()); setTextColor(Color.WHITE)
            maxLines = 1; imeOptions = EditorInfo.IME_ACTION_SEND; inputType = android.text.InputType.TYPE_CLASS_TEXT
            setOnEditorActionListener { _, _, _ -> sendChat(true); true }
        }
        chatBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xDD111318.toInt()); setPadding(dp(8), dp(4), dp(8), dp(4)); visibility = View.GONE
            addView(chatInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(Button(this@GameActivity).apply { text = "Enviar"; setOnClickListener { sendChat(true) } })
            addView(Button(this@GameActivity).apply { text = "⏎"; setOnClickListener { sendChat(false, enterOnly = true) } })
        }
        root.addView(chatBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        flashBtn = TextView(this).apply {
            text = "⚡ Activar modo Flash"; textSize = 15f; setTextColor(Color.BLACK)
            setPadding(dp(14), dp(8), dp(14), dp(8)); visibility = View.GONE
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0xFFFFC107.toInt()) }
            setOnClickListener { activateFlash() }
        }
        root.addView(flashBtn, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(8) })

        // --- menú flotante
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        fun add(label: String, f: () -> Unit) = row.addView(btn(label, f))
        add("←") { if (web.canGoBack()) web.goBack() else finish() }
        add("↻") { web.reload() }
        add("⚡") { activateFlash() }
        add("🎮") { toggleControls() }
        add("✏️") { controls.editMode = !controls.editMode; if (controls.editMode) showControls() }
        add("＋") { addControlDialog() }
        add("⟲") { confirmReset() }
        add("🖱") { setMouse(mouse.visibility != View.VISIBLE) }
        add("🔍+") { runCatching { web.zoomIn() } }
        add("🔍−") { runCatching { web.zoomOut() } }
        add("1:1") { resetZoom() }
        add("⛶") { s.fullscreen = !s.fullscreen; applyWindowMode() }
        add("🎚") { qualityDialog() }
        add("💬") { onChat() }
        add("⌨") { onKeyboard() }
        add("🐞") { showDiagnostics() }
        add("⚙") { showSettings() }
        add("✕") { finish() }
        menuBar = HorizontalScrollView(this).apply {
            addView(row); isHorizontalScrollBarEnabled = false; visibility = View.GONE
            setBackgroundColor(0xCC111318.toInt())
        }
        root.addView(menuBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.START).apply { leftMargin = dp(52) })

        val gear = btn("☰") { menuBar.visibility = if (menuBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        gear.alpha = 0.6f
        root.addView(gear, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START).apply { setMargins(dp(4), dp(4), 0, 0) })

        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }
    }

    private fun match() = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    private fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xAA2B2F3A.toInt()) }
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(40)).apply { setMargins(dp(2), 0, dp(2), 0) }
        setOnClickListener { onClick() }
    }

    // ================================================================ WebView
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            javaScriptCanOpenWindowsAutomatically = true
            allowFileAccess = false
        }
        applyUserAgent()
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        installScript()
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "LDNative", setOf("*"),
                WebViewCompat.WebMessageListener { _, message, _, _, _ -> onFlashReport(message.data) })
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (r.url.host == HOST) return serveLocal(r.url)
                val fromPlayer = r.requestHeaders["Origin"] == "https://$HOST"
                if (!fromPlayer && (r.url.path ?: "").endsWith(".swf", true)) noteSwf(r.url.toString())
                // Peticiones del reproductor propio: se hacen nativamente y se les añade CORS
                if (fromPlayer && r.method == "GET") return proxyFetch(r)
                return null
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                if (url?.contains(HOST) != true) { synchronized(detected) { detected.clear() }; flashBtn.visibility = View.GONE }
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) view.evaluateJavascript(buildScript(), null)
            }

            override fun onScaleChanged(view: WebView?, oldScale: Float, newScale: Float) {
                pageScale = newScale; if (baseScale == 0f) baseScale = newScale
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                customCb = callback; fsContainer.removeAllViews(); fsContainer.addView(view); fsContainer.visibility = View.VISIBLE
            }
            override fun onHideCustomView() { hideCustomView() }
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                addLog("[${m.messageLevel()}] ${m.message()} (${m.sourceId().substringAfterLast('/')}:${m.lineNumber()})")
                return true
            }
        }
    }

    private fun hideCustomView() {
        fsContainer.removeAllViews(); fsContainer.visibility = View.GONE
        customCb?.onCustomViewHidden(); customCb = null
    }

    private fun applyUserAgent() {
        currentUa = if (s.desktopMode) DESKTOP_UA else WebSettings.getDefaultUserAgent(this)
        web.settings.userAgentString = currentUa
    }

    /** config + inject.js + ruffle.js (síncrono, para que el polyfill exista antes que los scripts de la página). */
    private fun buildScript(): String {
        val q = s.effectiveQuality()
        val cfg = JSONObject()
            .put("publicPath", "https://$HOST/ruffle/")
            .put("quality", Settings.RUFFLE_Q[q])
            .put("dpr", Settings.DPR[q].toDouble())
            .put("renderer", Settings.RENDERER_IDS[s.renderer])
        val inject = assets.open("inject.js").bufferedReader().use { it.readText() }
        return "window.__LD_CONFIG=$cfg;\n$inject\n${ruffleJs ?: ""}"
    }

    private fun installScript() {
        scriptHandler?.remove(); scriptHandler = null
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, buildScript(), setOf("*"))
        }
    }

    /** Sirve ruffle.js/wasm, el reproductor y el .swf local desde la app (con CORS abierto). */
    private fun serveLocal(u: Uri): WebResourceResponse {
        val headers = mutableMapOf(
            "Access-Control-Allow-Origin" to "*",
            "Cross-Origin-Resource-Policy" to "cross-origin",
            "Cache-Control" to "no-cache"
        )
        return try {
            val path = u.path ?: "/"
            val stream: InputStream
            val mime: String
            when {
                path == "/local.swf" -> { stream = contentResolver.openInputStream(swfUri!!)!!; mime = "application/x-shockwave-flash" }
                path == "/player.html" -> { stream = assets.open("player.html"); mime = "text/html" }
                path.startsWith("/ruffle/") -> {
                    val n = path.removePrefix("/ruffle/")
                    stream = assets.open("ruffle/$n"); mime = mimeFor(n)
                }
                else -> throw java.io.FileNotFoundException(path)
            }
            addLog("local OK ${u.path}")
            WebResourceResponse(mime, null, 200, "OK", headers, stream)
        } catch (e: Exception) {
            addLog("local 404 ${u.path}")
            WebResourceResponse("text/plain", "utf-8", 404, "Not Found", headers, ByteArrayInputStream(ByteArray(0)))
        }
    }

    private fun mimeFor(n: String) = when {
        n.endsWith(".js") || n.endsWith(".mjs") -> "text/javascript"
        n.endsWith(".wasm") -> "application/wasm"
        n.endsWith(".json") -> "application/json"
        n.endsWith(".html") -> "text/html"
        n.endsWith(".css") -> "text/css"
        else -> "application/octet-stream"
    }

    private fun js(code: String) = web.evaluateJavascript(code, null)

    // ================================================================ ventana / pantalla completa
    private fun applyWindowMode() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (s.fullscreen) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else c.show(WindowInsetsCompat.Type.systemBars())
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        requestedOrientation = if (s.landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (s.keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ================================================================ acciones del menú
    private fun toggleControls() {
        s.controlsVisible = !s.controlsVisible
        controls.visibility = if (s.controlsVisible) View.VISIBLE else View.GONE
        if (!s.controlsVisible) controls.editMode = false
    }

    private fun showControls() { s.controlsVisible = true; controls.visibility = View.VISIBLE }

    private fun setMouse(on: Boolean) { mouse.visibility = if (on) View.VISIBLE else View.GONE }

    private fun resetZoom() {
        if (baseScale > 0f && pageScale > 0f) runCatching { web.zoomBy((baseScale / pageScale).coerceIn(0.01f, 100f)) }
    }

    private fun addControlDialog() {
        val names = arrayOf("Tecla", "D-pad (WASD / flechas)", "Clic izquierdo", "Clic derecho", "Botón mouse virtual", "Botón teclado", "Botón chat")
        val types = arrayOf(Ctl.KEY, Ctl.DPAD, Ctl.MOUSE_L, Ctl.MOUSE_R, Ctl.MOUSE_TOGGLE, Ctl.KEYBOARD, Ctl.CHAT)
        AlertDialog.Builder(this).setTitle("Añadir control").setItems(names) { _, i -> showControls(); controls.addControl(types[i]) }.show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this).setTitle("Restablecer controles").setMessage("Se perderá tu distribución actual.")
            .setPositiveButton("Restablecer") { _, _ -> controls.resetToDefaults() }.setNegativeButton("Cancelar", null).show()
    }

    private fun qualityDialog() {
        AlertDialog.Builder(this).setTitle("Calidad gráfica" + if (s.lowRam) " (RAM baja activa: mínima)" else "")
            .setSingleChoiceItems(Settings.QUALITY_NAMES, s.quality) { dlg, i ->
                s.quality = i; dlg.dismiss(); installScript(); web.reload()
            }.show()
    }

    private fun showSettings() {
        var reload = false
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        fun check(t: String, v: Boolean, f: (Boolean) -> Unit) {
            box.addView(CheckBox(this).apply { text = t; isChecked = v; setOnCheckedChangeListener { _, b -> f(b) } })
        }
        fun seek(t: String, max: Int, v: Int, f: (Int) -> Unit) {
            box.addView(TextView(this).apply { text = t; setPadding(0, dp(10), 0, 0) })
            box.addView(SeekBar(this).apply {
                this.max = max; progress = v
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { if (user) f(p) }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            })
        }
        check("Modo RAM baja (calidad mínima y menos memoria)", s.lowRam) { s.lowRam = it; reload = true }
        check("Modo escritorio (user-agent de PC)", s.desktopMode) { s.desktopMode = it; reload = true }
        check("Pantalla completa", s.fullscreen) { s.fullscreen = it; applyWindowMode() }
        check("Forzar horizontal", s.landscape) { s.landscape = it; applyWindowMode() }
        check("Mantener pantalla encendida", s.keepOn) { s.keepOn = it; applyWindowMode() }
        seek("Opacidad de controles", 100, (s.controlsAlpha * 100).toInt()) {
            s.controlsAlpha = maxOf(0.1f, it / 100f); controls.controlAlpha = s.controlsAlpha
        }
        seek("Velocidad del mouse virtual", 40, (s.mouseSpeed * 10).toInt()) {
            s.mouseSpeed = maxOf(0.3f, it / 10f); mouse.speed = s.mouseSpeed
        }
        box.addView(Button(this).apply {
            text = "Renderizador de Ruffle: " + Settings.RENDERER_NAMES[s.renderer]
            setOnClickListener {
                AlertDialog.Builder(this@GameActivity).setTitle("Renderizador (si ves negro, prueba canvas)")
                    .setSingleChoiceItems(Settings.RENDERER_NAMES, s.renderer) { d, i ->
                        s.renderer = i; d.dismiss(); text = "Renderizador de Ruffle: " + Settings.RENDERER_NAMES[i]; reload = true
                    }.show()
            }
        })
        box.addView(Button(this).apply {
            text = "Borrar caché y cookies"
            setOnClickListener { web.clearCache(true); CookieManager.getInstance().removeAllCookies(null); Toast.makeText(this@GameActivity, "Listo", Toast.LENGTH_SHORT).show() }
        })
        AlertDialog.Builder(this).setTitle("Ajustes").setView(android.widget.ScrollView(this).apply { addView(box) })
            .setPositiveButton("Cerrar", null)
            .setOnDismissListener { if (reload) { applyUserAgent(); installScript(); web.reload() } }
            .show()
    }

    // ================================================================ modo Flash
    private fun noteSwf(url: String) {
        if (url.contains("empty.swf")) return
        val added = synchronized(detected) { if (detected.containsKey(url)) false else { detected[url] = SwfInfo(url, "", ""); true } }
        if (added) runOnUiThread { if (web.url?.contains(HOST) != true) flashBtn.visibility = View.VISIBLE }
    }

    private fun onFlashReport(data: String?) {
        if (data == null || web.url?.contains(HOST) == true) return
        try {
            val o = JSONObject(data)
            val arr = o.getJSONArray("items")
            var any = o.optInt("plain") > 0
            synchronized(detected) {
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    val u = e.getString("url")
                    detected.getOrPut(u) { SwfInfo(u, e.optString("fv"), e.optString("base")) }
                    any = true
                }
            }
            if (any) flashBtn.visibility = View.VISIBLE
        } catch (_: Exception) {}
    }

    private fun activateFlash() {
        flashBtn.visibility = View.GONE
        js("window.__ld&&__ld.flashMode()")
        val list = synchronized(detected) { detected.values.toList() }
        if (list.isEmpty()) {
            Toast.makeText(this, "Modo Flash activado: Ruffle forzado en la página", Toast.LENGTH_LONG).show()
            return
        }
        val labels = list.map { (Uri.parse(it.url).lastPathSegment ?: it.url) + "  —  " + (Uri.parse(it.url).host ?: "") }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Ruffle forzado. ¿No se ve? Abre el SWF aparte:")
            .setItems(labels) { _, i -> openSwf(list[i]) }
            .setNegativeButton("Cerrar", null).show()
    }

    private fun openSwf(i: SwfInfo) {
        playerReferer = web.url
        web.loadUrl("https://$HOST/player.html?src=${Uri.encode(i.url)}&fv=${Uri.encode(i.fv)}&base=${Uri.encode(i.base)}")
    }

    /** Descarga nativa (sin CORS) para el reproductor propio; usa cookies y Referer del juego. */
    private fun proxyFetch(r: WebResourceRequest): WebResourceResponse? = try {
        val url = r.url.toString()
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", currentUa)
        r.requestHeaders["Accept"]?.let { c.setRequestProperty("Accept", it) }
        r.requestHeaders["Accept-Language"]?.let { c.setRequestProperty("Accept-Language", it) }
        playerReferer?.let { c.setRequestProperty("Referer", it) }
        CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
        val code = c.responseCode
        if (code in 300..399 || code < 100) null else {
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val mime = (c.contentType ?: "application/octet-stream").substringBefore(';').trim()
            val h = mutableMapOf("Access-Control-Allow-Origin" to "*", "Access-Control-Allow-Headers" to "*")
            WebResourceResponse(mime, null, code, c.responseMessage?.takeIf { it.isNotBlank() } ?: "OK", h, stream ?: ByteArrayInputStream(ByteArray(0)))
        }
    } catch (e: Exception) { addLog("proxy error ${r.url}: $e"); null }

    // ================================================================ diagnóstico
    private fun showDiagnostics() {
        val probe = "(function(){try{return JSON.stringify({ld:!!window.__ld,ruffle:!!window.RufflePlayer," +
            "version:(window.RufflePlayer&&window.RufflePlayer.version)||null," +
            "players:document.querySelectorAll('ruffle-player,ruffle-object,ruffle-embed').length," +
            "embeds:document.querySelectorAll('embed,object').length," +
            "iframes:Array.prototype.map.call(document.querySelectorAll('iframe'),function(f){return (f.src||'').slice(0,80)})," +
            "plain:Array.prototype.map.call(document.querySelectorAll('embed,object'),function(e){return e.outerHTML.slice(0,250)})," +
            "canvas:Array.prototype.map.call(document.querySelectorAll('canvas'),function(c){return c.width+'x'+c.height})," +
            "url:location.href})}catch(e){return 'err '+e}})()"
        web.evaluateJavascript(probe) { r ->
            val wv = if (Build.VERSION.SDK_INT >= 26) WebView.getCurrentWebViewPackage()?.let { "${it.packageName} ${it.versionName}" } ?: "?" else "?"
            val head = "WebView: $wv\n" +
                "Ruffle en assets: " + (ruffleJs?.let { "OK (${it.length / 1024} KB)" } ?: "FALTA") + "\n" +
                "Script al inicio soportado: ${WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)}\n" +
                "Calidad efectiva: ${s.effectiveQuality()}\n" +
                "SWF detectados: " + synchronized(detected) { detected.keys.joinToString(" | ") }.ifEmpty { "ninguno" } + "\n" +
                "Página: $r\n\n--- consola / archivos ---\n"
            val text = head + synchronized(logs) { logs.joinToString("\n") }
            val tv = TextView(this).apply {
                this.text = text; textSize = 11f; typeface = android.graphics.Typeface.MONOSPACE
                setTextIsSelectable(true); setPadding(dp(16), dp(8), dp(16), dp(8))
            }
            AlertDialog.Builder(this).setTitle("Diagnóstico")
                .setView(android.widget.ScrollView(this).apply { addView(tv) })
                .setPositiveButton("Copiar") { _, _ ->
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("diag", text))
                    Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
                }.setNegativeButton("Cerrar", null).show()
        }
    }

    // ================================================================ chat / teclado
    override fun onChat() {
        if (chatBar.visibility == View.VISIBLE) {
            chatBar.visibility = View.GONE; hideIme(); web.requestFocus()
        } else {
            chatBar.visibility = View.VISIBLE; chatInput.requestFocus()
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(chatInput, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun sendChat(withEnter: Boolean, enterOnly: Boolean = false) {
        val text = if (enterOnly) "" else chatInput.text.toString()
        if (enterOnly) js("window.__ld&&__ld.type('',true)")
        else if (text.isNotEmpty()) { js("window.__ld&&__ld.type(${JSONObject.quote(text)},$withEnter)"); chatInput.setText("") }
    }

    @Suppress("DEPRECATION")
    override fun onKeyboard() {
        web.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
    }

    private fun hideIme() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(root.windowToken, 0)
    }

    // ================================================================ ControlsOverlay.Host
    override fun onKey(def: KeyDef, down: Boolean) {
        val o = JSONObject().put("key", def.key).put("code", def.code).put("kc", def.keyCode)
        js("window.__ld&&__ld.key('${if (down) "down" else "up"}',$o)")
    }

    override fun onMouseButton(button: Int, down: Boolean) {
        if (mouse.visibility != View.VISIBLE) setMouse(true)
        if (down) mouse.press(button) else mouse.release(button)
    }

    override fun onToggleMouse() { setMouse(mouse.visibility != View.VISIBLE) }

    override fun onLayoutChanged(items: List<Ctl>) { s.saveLayout(profile, ControlLayout.toJson(items)) }

    // ================================================================ VirtualMouseView.Host
    // Se inyectan eventos NATIVOS de mouse (clic izq/der, arrastre y hover) en el WebView.
    private fun mouseEvent(action: Int, x: Float, y: Float, buttons: Int): MotionEvent {
        val p = MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_MOUSE }
        val c = MotionEvent.PointerCoords().apply { this.x = x; this.y = y; pressure = if (buttons != 0) 1f else 0f; size = 1f }
        return MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, 1, arrayOf(p), arrayOf(c),
            0, buttons, 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0)
    }

    private fun btnMask(b: Int) = if (b == 2) MotionEvent.BUTTON_SECONDARY else MotionEvent.BUTTON_PRIMARY

    override fun hover(x: Float, y: Float) {
        val e = mouseEvent(MotionEvent.ACTION_HOVER_MOVE, x, y, 0); web.dispatchGenericMotionEvent(e); e.recycle()
    }
    override fun down(x: Float, y: Float, button: Int) {
        downTime = SystemClock.uptimeMillis()
        val e = mouseEvent(MotionEvent.ACTION_DOWN, x, y, btnMask(button)); web.dispatchTouchEvent(e); e.recycle()
    }
    override fun move(x: Float, y: Float, button: Int) {
        val e = mouseEvent(MotionEvent.ACTION_MOVE, x, y, btnMask(button)); web.dispatchTouchEvent(e); e.recycle()
    }
    override fun up(x: Float, y: Float, button: Int) {
        val e = mouseEvent(MotionEvent.ACTION_UP, x, y, 0); web.dispatchTouchEvent(e); e.recycle()
    }
}

/** Archivo Flash detectado en la página. */
data class SwfInfo(val url: String, val fv: String, val base: String)
