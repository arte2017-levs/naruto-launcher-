package com.flashlauncher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Settings(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("flash_launcher", Context.MODE_PRIVATE)

    /** 0=Mínima 1=Baja 2=Media 3=Alta 4=Máxima */
    var quality: Int
        get() = sp.getInt("quality", 2)
        set(v) = sp.edit().putInt("quality", v).apply()
    var lowRam: Boolean
        get() = sp.getBoolean("lowRam", false)
        set(v) = sp.edit().putBoolean("lowRam", v).apply()
    var desktopMode: Boolean
        get() = sp.getBoolean("desktop", true)
        set(v) = sp.edit().putBoolean("desktop", v).apply()
    var controlsVisible: Boolean
        get() = sp.getBoolean("ctlVisible", true)
        set(v) = sp.edit().putBoolean("ctlVisible", v).apply()
    var controlsAlpha: Float
        get() = sp.getFloat("ctlAlpha", 0.55f)
        set(v) = sp.edit().putFloat("ctlAlpha", v).apply()
    var mouseSpeed: Float
        get() = sp.getFloat("mouseSpeed", 1.4f)
        set(v) = sp.edit().putFloat("mouseSpeed", v).apply()
    var fullscreen: Boolean
        get() = sp.getBoolean("fullscreen", true)
        set(v) = sp.edit().putBoolean("fullscreen", v).apply()
    var landscape: Boolean
        get() = sp.getBoolean("landscape", true)
        set(v) = sp.edit().putBoolean("landscape", v).apply()
    var keepOn: Boolean
        get() = sp.getBoolean("keepOn", true)
        set(v) = sp.edit().putBoolean("keepOn", v).apply()

    /** 0=auto 1=wgpu-webgl 2=webgl 3=canvas */
    var renderer: Int
        get() = sp.getInt("renderer", 0)
        set(v) = sp.edit().putInt("renderer", v).apply()

    /** En modo RAM baja siempre se usa la calidad mínima. */
    fun effectiveQuality() = if (lowRam) 0 else quality

    fun layoutJson(profile: String): String? = sp.getString("layout_$profile", null)
    fun saveLayout(profile: String, json: String) = sp.edit().putString("layout_$profile", json).apply()

    fun games(): MutableList<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        val raw = sp.getString("games", null)
        if (raw == null) {
            out.add("Demo de Ruffle" to "https://ruffle.rs/demo/")
            saveGames(out)
            return out
        }
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(o.getString("name") to o.getString("url"))
        }
        return out
    }

    fun saveGames(list: List<Pair<String, String>>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.first).put("url", it.second)) }
        sp.edit().putString("games", arr.toString()).apply()
    }

    companion object {
        val RENDERER_NAMES = arrayOf("Automático", "wgpu-webgl", "webgl", "canvas (más compatible)")
        val RENDERER_IDS = arrayOf("", "wgpu-webgl", "webgl", "canvas")
        val QUALITY_NAMES = arrayOf("Mínima (teléfonos muy lentos)", "Baja", "Media", "Alta", "Máxima (nativa)")
        val RUFFLE_Q = arrayOf("low", "low", "medium", "high", "best")
        /** devicePixelRatio forzado; 0 = el real del teléfono */
        val DPR = floatArrayOf(0.5f, 0.75f, 1f, 1.5f, 0f)
    }
}
