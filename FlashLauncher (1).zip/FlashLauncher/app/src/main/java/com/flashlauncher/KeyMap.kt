package com.flashlauncher

data class KeyDef(val key: String, val code: String, val keyCode: Int)

object KeyMap {
    private val named = mapOf(
        "esc" to KeyDef("Escape", "Escape", 27),
        "space" to KeyDef(" ", "Space", 32),
        "enter" to KeyDef("Enter", "Enter", 13),
        "shift" to KeyDef("Shift", "ShiftLeft", 16),
        "ctrl" to KeyDef("Control", "ControlLeft", 17),
        "alt" to KeyDef("Alt", "AltLeft", 18),
        "tab" to KeyDef("Tab", "Tab", 9),
        "backspace" to KeyDef("Backspace", "Backspace", 8),
        "del" to KeyDef("Delete", "Delete", 46),
        "up" to KeyDef("ArrowUp", "ArrowUp", 38),
        "down" to KeyDef("ArrowDown", "ArrowDown", 40),
        "left" to KeyDef("ArrowLeft", "ArrowLeft", 37),
        "right" to KeyDef("ArrowRight", "ArrowRight", 39)
    )

    /** "w", "esc", "space", "f5", "1"... -> definición de tecla (null si no es válida). */
    fun resolve(name: String): KeyDef? {
        val n = name.trim().lowercase()
        named[n]?.let { return it }
        if (n.length == 1) {
            val c = n[0]
            if (c in 'a'..'z') return KeyDef(n, "Key${c.uppercaseChar()}", c.uppercaseChar().code)
            if (c in '0'..'9') return KeyDef(n, "Digit$c", c.code)
        }
        Regex("f(\\d{1,2})").matchEntire(n)?.let {
            val i = it.groupValues[1].toInt()
            if (i in 1..12) return KeyDef("F$i", "F$i", 111 + i)
        }
        return null
    }
}
