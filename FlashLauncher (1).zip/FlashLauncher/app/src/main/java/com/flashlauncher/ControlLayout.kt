package com.flashlauncher

import org.json.JSONArray
import org.json.JSONObject

/** Un control en pantalla. x,y = centro como fracción (0..1) del ancho/alto. size en dp. */
data class Ctl(
    var id: String,
    var type: String,
    var label: String,
    var keys: String,
    var x: Float,
    var y: Float,
    var size: Int
) {
    companion object {
        const val KEY = "KEY"                 // tecla simple (mantener = keydown)
        const val DPAD = "DPAD"               // 4 teclas: arriba,izq,abajo,der
        const val MOUSE_L = "MOUSE_L"
        const val MOUSE_R = "MOUSE_R"
        const val MOUSE_TOGGLE = "MOUSE_TOGGLE"
        const val KEYBOARD = "KEYBOARD"
        const val CHAT = "CHAT"
    }
}

object ControlLayout {
    private var n = 0
    private fun c(type: String, keys: String, x: Float, y: Float, size: Int, label: String = "") =
        Ctl("d${n++}", type, label, keys, x, y, size)

    fun defaults(): MutableList<Ctl> = mutableListOf(
        c(Ctl.DPAD, "w,a,s,d", 0.14f, 0.70f, 150),
        c(Ctl.KEY, "esc", 0.94f, 0.10f, 48),
        c(Ctl.KEY, "space", 0.90f, 0.72f, 64),
        c(Ctl.KEY, "e", 0.80f, 0.82f, 52),
        c(Ctl.KEY, "q", 0.80f, 0.60f, 52),
        c(Ctl.KEY, "1", 0.34f, 0.92f, 44),
        c(Ctl.KEY, "2", 0.41f, 0.92f, 44),
        c(Ctl.KEY, "3", 0.48f, 0.92f, 44),
        c(Ctl.KEY, "4", 0.55f, 0.92f, 44),
        c(Ctl.MOUSE_TOGGLE, "", 0.94f, 0.25f, 46),
        c(Ctl.KEYBOARD, "", 0.94f, 0.38f, 46),
        c(Ctl.CHAT, "", 0.94f, 0.51f, 46),
        c(Ctl.MOUSE_L, "", 0.68f, 0.84f, 52),
        c(Ctl.MOUSE_R, "", 0.58f, 0.84f, 52)
    )

    fun toJson(list: List<Ctl>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("type", it.type).put("label", it.label)
                .put("keys", it.keys).put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("size", it.size))
        }
        return arr.toString()
    }

    fun fromJson(s: String?): MutableList<Ctl> {
        if (s.isNullOrBlank()) return defaults()
        return try {
            val arr = JSONArray(s)
            MutableList(arr.length()) {
                val o = arr.getJSONObject(it)
                Ctl(o.getString("id"), o.getString("type"), o.optString("label"), o.optString("keys"),
                    o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.getInt("size"))
            }
        } catch (e: Exception) { defaults() }
    }
}
