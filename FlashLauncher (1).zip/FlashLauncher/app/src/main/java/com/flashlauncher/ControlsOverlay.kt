package com.flashlauncher

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.UUID
import kotlin.math.abs
import kotlin.math.min

/** Capa de controles táctiles editables (botones, D-pad WASD, etc.). */
class ControlsOverlay(private val ctx: Context) : FrameLayout(ctx) {

    interface Host {
        fun onKey(def: KeyDef, down: Boolean)
        fun onMouseButton(button: Int, down: Boolean)
        fun onToggleMouse()
        fun onKeyboard()
        fun onChat()
        fun onLayoutChanged(items: List<Ctl>)
    }

    var host: Host? = null
    var items: MutableList<Ctl> = mutableListOf()
        private set
    var controlAlpha = 0.55f
        set(v) { field = v; applyAlpha() }
    var editMode = false
        set(v) { field = v; applyAlpha(); for (i in 0 until childCount) getChildAt(i).invalidate() }

    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = 0xFFFFFFFF.toInt() }

    fun setItems(list: MutableList<Ctl>) { items = list; rebuild() }

    fun addControl(type: String) {
        val keys = when (type) { Ctl.DPAD -> "w,a,s,d"; Ctl.KEY -> "e"; else -> "" }
        val c = Ctl(UUID.randomUUID().toString(), type, "", keys, 0.5f, 0.5f, if (type == Ctl.DPAD) 150 else 52)
        items.add(c); rebuild(); host?.onLayoutChanged(items)
        editMode = true
        showEditDialog(c)
    }

    fun resetToDefaults() { items = ControlLayout.defaults(); rebuild(); host?.onLayoutChanged(items) }

    private fun rebuild() {
        removeAllViews()
        for (c in items) {
            val v: CtlView = if (c.type == Ctl.DPAD) DpadView(c) else PadButton(c)
            val s = (c.size * d).toInt()
            addView(v, FrameLayout.LayoutParams(s, s))
        }
        applyAlpha(); requestLayout()
    }

    private fun applyAlpha() {
        for (i in 0 until childCount) getChildAt(i).alpha = if (editMode) 1f else controlAlpha
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l; val h = b - t
        for (i in 0 until childCount) {
            val v = getChildAt(i); val c = v.tag as Ctl
            val s = (c.size * d).toInt()
            val cx = (c.x * w).toInt(); val cy = (c.y * h).toInt()
            v.layout(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2)
        }
    }

    // ---------------------------------------------------------------- vistas
    private abstract inner class CtlView(val ctl: Ctl) : View(ctx) {
        private var sx = 0f; private var sy = 0f; private var ox = 0f; private var oy = 0f
        private var moved = false
        init { tag = ctl }

        abstract fun handleTouch(e: MotionEvent): Boolean

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (!editMode) return handleTouch(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = ctl.x; oy = ctl.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 8 * d || abs(dy) > 8 * d) moved = true
                    if (moved && this@ControlsOverlay.width > 0) {
                        ctl.x = (ox + dx / this@ControlsOverlay.width).coerceIn(0.02f, 0.98f)
                        ctl.y = (oy + dy / this@ControlsOverlay.height).coerceIn(0.02f, 0.98f)
                        this@ControlsOverlay.requestLayout()
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) host?.onLayoutChanged(items) else showEditDialog(ctl)
            }
            return true
        }

        protected fun drawOutline(c: Canvas, r: Float) {
            stroke.color = if (editMode) 0xFFFFC107.toInt() else 0xFFFFFFFF.toInt()
            c.drawCircle(width / 2f, height / 2f, r, stroke)
        }
    }

    private inner class PadButton(ctl: Ctl) : CtlView(ctl) {
        private var pressed = false

        override fun handleTouch(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { pressed = true; invalidate(); fire(true) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (pressed) { pressed = false; invalidate(); fire(false) }
            }
            return true
        }

        private fun fire(down: Boolean) {
            when (ctl.type) {
                Ctl.KEY -> KeyMap.resolve(ctl.keys)?.let { host?.onKey(it, down) }
                Ctl.MOUSE_L -> host?.onMouseButton(1, down)
                Ctl.MOUSE_R -> host?.onMouseButton(2, down)
                Ctl.MOUSE_TOGGLE -> if (down) host?.onToggleMouse()
                Ctl.KEYBOARD -> if (down) host?.onKeyboard()
                Ctl.CHAT -> if (down) host?.onChat()
            }
        }

        private fun label(): String = if (ctl.label.isNotBlank()) ctl.label else when (ctl.type) {
            Ctl.MOUSE_L -> "L"; Ctl.MOUSE_R -> "R"; Ctl.MOUSE_TOGGLE -> "🖱"
            Ctl.KEYBOARD -> "⌨"; Ctl.CHAT -> "💬"; else -> ctl.keys.uppercase()
        }

        override fun onDraw(c: Canvas) {
            val r = min(width, height) / 2f - 2 * d
            fill.color = if (pressed) 0xFFFFFFFF.toInt() else 0xFF2B2F3A.toInt()
            c.drawCircle(width / 2f, height / 2f, r, fill)
            drawOutline(c, r)
            val text = label()
            txt.color = if (pressed) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            txt.textSize = r * (if (text.length <= 2) 0.85f else 0.5f)
            c.drawText(text, width / 2f, height / 2f - (txt.descent() + txt.ascent()) / 2, txt)
        }
    }

    private inner class DpadView(ctl: Ctl) : CtlView(ctl) {
        private val act = BooleanArray(4) // arriba, izq, abajo, der
        private fun defs(): List<KeyDef?> =
            ctl.keys.split(",").map { KeyMap.resolve(it) }.let { l -> List(4) { l.getOrNull(it) } }

        override fun handleTouch(e: MotionEvent): Boolean {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                set(false, false, false, false); return true
            }
            val nx = (e.x - width / 2f) / (width / 2f)
            val ny = (e.y - height / 2f) / (height / 2f)
            set(ny < -0.3f, nx < -0.3f, ny > 0.3f, nx > 0.3f)
            return true
        }

        private fun set(up: Boolean, left: Boolean, down: Boolean, right: Boolean) {
            val n = booleanArrayOf(up, left, down, right)
            val ds = defs()
            for (i in 0..3) if (n[i] != act[i]) { act[i] = n[i]; ds[i]?.let { host?.onKey(it, n[i]) } }
            invalidate()
        }

        override fun onDraw(c: Canvas) {
            val r = min(width, height) / 2f - 2 * d
            val cx = width / 2f; val cy = height / 2f
            fill.color = 0x663B4252; c.drawCircle(cx, cy, r, fill)
            drawOutline(c, r)
            val names = ctl.keys.split(",").map { it.trim().uppercase() }
            val pos = arrayOf(0f to -0.62f, -0.62f to 0f, 0f to 0.62f, 0.62f to 0f)
            for (i in 0..3) {
                val px = cx + pos[i].first * r; val py = cy + pos[i].second * r
                fill.color = if (act[i]) 0xFFFFFFFF.toInt() else 0xFF2B2F3A.toInt()
                c.drawCircle(px, py, r * 0.26f, fill)
                txt.color = if (act[i]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
                txt.textSize = r * 0.28f
                c.drawText(names.getOrNull(i)?.take(3) ?: "", px, py - (txt.descent() + txt.ascent()) / 2, txt)
            }
        }
    }

    // ----------------------------------------------------------- edición
    private fun showEditDialog(c: Ctl) {
        val pad = (16 * d).toInt()
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        val label = EditText(ctx).apply { hint = "Etiqueta (opcional)"; setText(c.label) }
        val keys = EditText(ctx).apply {
            hint = if (c.type == Ctl.DPAD) "arriba,izq,abajo,der  (w,a,s,d)" else "Tecla: a-z, 0-9, space, esc, enter, shift, up, f1…"
            setText(c.keys)
        }
        val size = SeekBar(ctx).apply { max = 160; progress = (c.size - 40).coerceIn(0, 160) }
        box.addView(label)
        val hasKeys = c.type == Ctl.KEY || c.type == Ctl.DPAD
        if (hasKeys) box.addView(keys)
        box.addView(TextView(ctx).apply { text = "Tamaño"; setPadding(0, pad, 0, 0) })
        box.addView(size)

        AlertDialog.Builder(ctx)
            .setTitle("Editar control")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                c.label = label.text.toString()
                c.size = size.progress + 40
                if (hasKeys) {
                    val k = keys.text.toString().trim()
                    val ok = if (c.type == Ctl.KEY) KeyMap.resolve(k) != null
                             else k.split(",").size == 4 && k.split(",").all { KeyMap.resolve(it) != null }
                    if (ok) c.keys = k else Toast.makeText(ctx, "Tecla(s) no válida(s)", Toast.LENGTH_SHORT).show()
                }
                rebuild(); host?.onLayoutChanged(items)
            }
            .setNegativeButton("Eliminar") { _, _ -> items.remove(c); rebuild(); host?.onLayoutChanged(items) }
            .setNeutralButton("Cancelar", null)
            .show()
    }
}
