package com.flashlauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/** Touchpad con cursor: arrastrar = mover, toque rápido = clic. Los botones L/R llaman press()/release(). */
class VirtualMouseView(ctx: Context) : View(ctx) {

    interface Host {
        fun hover(x: Float, y: Float)
        fun down(x: Float, y: Float, button: Int)
        fun move(x: Float, y: Float, button: Int)
        fun up(x: Float, y: Float, button: Int)
    }

    var host: Host? = null
    var speed = 1.4f
    var cx = -1f
        private set
    var cy = -1f
        private set
    private var held = 0
    private var lastX = 0f; private var lastY = 0f
    private var downAt = 0L; private var total = 0f
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF000000.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.5f * d }
    private val arrow = Path()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (cx < 0) { cx = w / 2f; cy = h / 2f }
        cx = cx.coerceIn(0f, w - 1f); cy = cy.coerceIn(0f, h - 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = e.x; lastY = e.y; downAt = e.eventTime; total = 0f }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.x - lastX) * speed; val dy = (e.y - lastY) * speed
                lastX = e.x; lastY = e.y
                total += hypot(dx, dy)
                cx = (cx + dx).coerceIn(0f, width - 1f); cy = (cy + dy).coerceIn(0f, height - 1f)
                if (held != 0) host?.move(cx, cy, held) else host?.hover(cx, cy)
                invalidate()
            }
            MotionEvent.ACTION_UP -> if (e.eventTime - downAt < 250 && total < 20 * d) {
                host?.down(cx, cy, 1)
                postDelayed({ host?.up(cx, cy, 1) }, 40)
            }
        }
        return true
    }

    fun press(button: Int) { held = button; host?.down(cx, cy, button) }
    fun release(button: Int) { host?.up(cx, cy, button); if (held == button) held = 0 }

    override fun onDraw(c: Canvas) {
        if (cx < 0) return
        arrow.reset()
        arrow.moveTo(cx, cy); arrow.lineTo(cx, cy + 20 * d); arrow.lineTo(cx + 5 * d, cy + 15 * d)
        arrow.lineTo(cx + 10 * d, cy + 24 * d); arrow.lineTo(cx + 13 * d, cy + 22 * d)
        arrow.lineTo(cx + 8 * d, cy + 13 * d); arrow.lineTo(cx + 15 * d, cy + 13 * d); arrow.close()
        c.drawPath(arrow, fill); c.drawPath(arrow, line)
    }
}
