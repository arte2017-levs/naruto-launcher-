package com.flashlauncher

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var s: Settings
    private lateinit var list: LinearLayout
    private lateinit var urlInput: EditText

    private val pickSwf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            startActivity(Intent(this, GameActivity::class.java)
                .putExtra(GameActivity.EXTRA_SWF, uri.toString())
                .putExtra(GameActivity.EXTRA_NAME, "swf:" + uri.lastPathSegment))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Settings(this)

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        col.addView(TextView(this).apply { text = "Flash Launcher"; textSize = 26f; setTextColor(Color.WHITE) })
        col.addView(TextView(this).apply {
            text = "Juegos Flash/SWF en línea con Ruffle, controles editables y mouse virtual."
            setTextColor(0xFF9AA4B2.toInt()); setPadding(0, dp(4), 0, dp(12))
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        urlInput = EditText(this).apply {
            hint = "URL del juego"; setHintTextColor(0xFF6B7280.toInt()); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_TEXT_VARIATION_URI; maxLines = 1
        }
        row.addView(urlInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply { text = "Ir"; setOnClickListener { open(urlInput.text.toString(), urlInput.text.toString()) } })
        col.addView(row)

        col.addView(Button(this).apply { text = "Abrir archivo .swf local"; setOnClickListener { pickSwf.launch(arrayOf("*/*")) } })
        col.addView(Button(this).apply { text = "+ Añadir juego a mi lista"; setOnClickListener { editGame(null) } })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        col.addView(list)

        setContentView(ScrollView(this).apply { addView(col); fitsSystemWindows = true })
        refresh()
    }

    private fun normalize(raw: String): String {
        val t = raw.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(" ") || !t.contains(".") -> "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(t, "UTF-8")
            else -> "https://$t"
        }
    }

    private fun open(name: String, url: String) {
        if (url.isBlank()) return
        startActivity(Intent(this, GameActivity::class.java)
            .putExtra(GameActivity.EXTRA_URL, normalize(url))
            .putExtra(GameActivity.EXTRA_NAME, name))
    }

    private fun refresh() {
        list.removeAllViews()
        val games = s.games()
        games.forEachIndexed { i, g ->
            list.addView(TextView(this).apply {
                text = "${g.first}\n${g.second}"
                setTextColor(Color.WHITE); setBackgroundColor(0xFF1E222B.toInt())
                setPadding(dp(14), dp(12), dp(14), dp(12))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { bottomMargin = dp(8) }
                setOnClickListener { open(g.first, g.second) }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setItems(arrayOf("Editar", "Eliminar")) { _, w ->
                        if (w == 0) editGame(i) else { games.removeAt(i); s.saveGames(games); refresh() }
                    }.show(); true
                }
            })
        }
    }

    private fun editGame(index: Int?) {
        val games = s.games()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Nombre"; setText(index?.let { games[it].first } ?: "") }
        val url = EditText(this).apply { hint = "https://…"; setText(index?.let { games[it].second } ?: "") }
        box.addView(name); box.addView(url)
        AlertDialog.Builder(this).setTitle(if (index == null) "Añadir juego" else "Editar juego").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                if (url.text.isNotBlank()) {
                    val g = (name.text.toString().ifBlank { url.text.toString() }) to normalize(url.text.toString())
                    if (index == null) games.add(g) else games[index] = g
                    s.saveGames(games); refresh()
                }
            }.setNegativeButton("Cancelar", null).show()
    }
}
