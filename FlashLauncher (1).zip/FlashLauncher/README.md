# Flash Launcher 🎮

Navegador/launcher Android para jugar juegos Flash en línea (Naruto Online, Legend II, Elarionis, etc.)
**sin salir de la app**, usando [Ruffle](https://ruffle.rs) (emulador de Flash/.swf en WebAssembly).

## Características
- **Ruffle integrado** (se inyecta en cada página e iframe antes de que cargue el juego; también abre archivos `.swf` locales).
- **Controles táctiles editables**: D-pad WASD, ESC, espacio, 1-4, etc. Modo ✏️ para arrastrar, cambiar tecla, tamaño, eliminar (＋ añadir, ⟲ restablecer). Se guardan **por juego**.
- **Mostrar/ocultar controles** (🎮) y opacidad ajustable.
- **Mouse virtual** (🖱): touchpad con cursor, toque = clic, botones L/R para clic izq/der y arrastrar (eventos de mouse nativos).
- **Pantalla completa** inmersiva (⛶), horizontal forzado, fullscreen HTML5 del propio juego.
- **Calidad 5 niveles + Modo RAM baja** (🎚 / ⚙): reduce calidad de Ruffle y la resolución del canvas (devicePixelRatio), libera caché y pausa en segundo plano.
- **Zoom**: pellizcar, 🔍+ / 🔍− / 1:1.
- **Chat**: barra 💬 que escribe texto en el juego (Enter incluido) + botón ⌨ para el teclado del sistema.
- Modo escritorio (user-agent de PC) para webs de juegos que bloquean móviles.

## Compilar
### Opción A: GitHub Actions (sin instalar nada)
1. Sube este proyecto a un repo de GitHub.
2. Pestaña **Actions → Build APK → Run workflow** (o haz push a `main`).
3. Descarga el APK en *Artifacts*. Si creas un tag `v1.0`, se publica en *Releases*.

### Opción B: local
```bash
./scripts/fetch_ruffle.sh        # descarga Ruffle a app/src/main/assets/ruffle
gradle wrapper --gradle-version 8.7   # una sola vez (o abre en Android Studio)
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/`.

## Estructura
```
app/src/main/
├─ assets/inject.js          # config Ruffle, calidad (DPR), envío de teclas/texto a iframes
├─ assets/player.html        # reproductor para .swf locales
└─ java/com/flashlauncher/
   ├─ MainActivity.kt        # lista de juegos, URL, abrir .swf
   ├─ GameActivity.kt        # WebView + Ruffle + menú + chat + ajustes + mouse nativo
   ├─ ControlsOverlay.kt     # controles editables (botones y D-pad)
   ├─ VirtualMouseView.kt    # cursor/touchpad
   ├─ ControlLayout.kt       # modelo + guardado JSON de controles
   ├─ KeyMap.kt              # nombre de tecla → key/code/keyCode
   └─ Settings.kt            # preferencias
```

## Limitaciones conocidas
- Ruffle no emula el 100 % de Flash: ActionScript 2 va muy bien; **AS3 es parcial**. Los MMO con sockets/AS3 complejo pueden fallar o cargar con errores.
- Páginas con CSP muy estricta pueden bloquear los chunks de Ruffle (se sirven desde `https://ruffle.local`).
- El chat dentro del SWF recibe teclas sintéticas; si algún juego no las acepta, usa el botón ⌨ (teclado del sistema).
- La calidad "Mínima" baja el DPR a 0.5: se ve borroso pero consume mucho menos RAM/CPU.
- Usa solo juegos/archivos que tengas derecho a usar y respeta los términos de cada servicio.

Ruffle © contributors, licencias MIT/Apache-2.0.
