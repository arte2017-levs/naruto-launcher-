#!/usr/bin/env bash
# Descarga la última versión "web-selfhosted" de Ruffle a app/src/main/assets/ruffle/
set -euo pipefail
cd "$(dirname "$0")/.."
DEST="app/src/main/assets/ruffle"
TMP="$(mktemp -d)"
AUTH=()
[ -n "${GITHUB_TOKEN:-}" ] && AUTH=(-H "Authorization: Bearer ${GITHUB_TOKEN}")

echo "Buscando última release de Ruffle..."
URL="$(curl -fsSL ${AUTH[@]+"${AUTH[@]}"} https://api.github.com/repos/ruffle-rs/ruffle/releases/latest \
  | grep -o 'https://[^"]*web-selfhosted[^"]*\.zip' | head -1)"
[ -n "$URL" ] || { echo "No se encontró el zip selfhosted"; exit 1; }

echo "Descargando $URL"
curl -fsSL "$URL" -o "$TMP/ruffle.zip"
unzip -qo "$TMP/ruffle.zip" -d "$TMP/x"
SRC="$(dirname "$(find "$TMP/x" -name ruffle.js | head -1)")"
rm -rf "$DEST"; mkdir -p "$DEST"
cp -r "$SRC"/* "$DEST"/
echo "Ruffle instalado en $DEST ($(ls "$DEST" | wc -l) archivos)"
